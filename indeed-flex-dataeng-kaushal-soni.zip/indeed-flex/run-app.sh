java -jar indeed-flex.jar worker_activity.csv result.csv
